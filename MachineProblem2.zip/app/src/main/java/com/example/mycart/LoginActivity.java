package com.example.itemcart;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mycart.LoggedinActivity;
import com.example.mycart.MainActivity;
import com.example.mycart.R;
import com.example.mycart.WrongEntry;

public class LoginActivity extends AppCompatDialogFragment {
    EditText txtEmail, txtPassword;
    Button btn_checkout;
    Context context;
    CharSequence text;
    int duration;
    Toast toast;


    @Override
    public Dialog onCreateDialog (Bundle saveInstanceState){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.activity_dialog_login, null);
        txtPassword = view.findViewById(R.id.txtPassword);
        txtEmail = view.findViewById(R.id.txtEmail);
        builder.setView(view)
                .setTitle("Please Login")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        if(txtEmail.getText().toString().equals("admin") && txtPassword.getText().toString().equals("123456")){
                            Intent id = new Intent(getContext(), LoggedinActivity.class);
                            getContext().startActivity(id);
                        }else {
                            Intent id = new Intent(getContext(), WrongEntry.class);
                            getContext().startActivity(id);

                        }

                    }

                });
        return builder.create();
    }



}
