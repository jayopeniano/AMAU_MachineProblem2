package com.example.mycart;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class LoggedinActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    EditText txtEmail, txtPassword;
    Button btn_checkout;
    CheckBox cbxBurger, cbxFries, cbxDrinks;
    TextView textView;
    ArrayList<String> StringArray = new ArrayList<>();
    Float orderPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);
        initViews();

        btn_checkout = (Button) findViewById(R.id.btn_checkout);
        cbxBurger = (CheckBox) findViewById(R.id.cbxBurger);
        btn_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(cbxBurger.isChecked()){

              }
              if(cbxFries.isChecked()){

                }
              if(cbxDrinks.isChecked()){

              }

            }
        });
    }

    public void initViews(){
        cbxBurger = findViewById(R.id.cbxBurger);
        cbxDrinks = findViewById(R.id.cbxDrinks);
        cbxFries = findViewById(R.id.cbxFries);
        textView = findViewById(R.id.action_text);

        cbxBurger.setOnCheckedChangeListener(this);
        cbxDrinks.setOnCheckedChangeListener(this);
        cbxFries.setOnCheckedChangeListener(this);
        setText();
    }
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(isChecked) {
            StringArray.add("" + buttonView.getText().toString());


        } else {
            StringArray.remove(StringArray.indexOf(buttonView.getText().toString()));
        }
        setText();
    }

    public void setText(){
        textView.setText("");
        for (int i=0; i<StringArray.size();i++) {
            textView.append(StringArray.get(i));
            textView.append(",");
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.logged_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        Context context = getApplicationContext();
        switch(item.getItemId()){
            case R.id.settings:

                break;
            case R.id.logout:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
        }
        return onOptionsItemSelected(item);
    }





}