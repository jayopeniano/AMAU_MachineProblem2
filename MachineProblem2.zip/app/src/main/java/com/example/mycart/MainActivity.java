package com.example.mycart;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    EditText txtEmail, txtPassword;
    CheckBox cbxFries, cbxBurger, cbxDrinks;
    Button btn_checkout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_checkout = (Button) findViewById(R.id.btn_checkout);
        btn_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*if(cbxBurger.isChecked()){

              }
              if(cbxFries.isChecked()){

                }
              if(cbxDrinks.isChecked()){

              }*/
                loginDialog();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void loginDialog(){
        com.example.itemcart.LoginActivity loginActivity = new com.example.itemcart.LoginActivity();
        loginActivity.show(getSupportFragmentManager(),"Login Form");
    }

     @Override
    public boolean onOptionsItemSelected(MenuItem item){
        Context context = getApplicationContext();
        switch(item.getItemId()){
            case R.id.settings:

                break;
            case R.id.login:
                loginDialog();
                break;
        }
        return  super.onOptionsItemSelected(item);
    }

}